<?php
declare(strict_types=1);

namespace chess;

use chess\game\GameManager;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\player\Player;

class EventListener implements Listener {

    private Main $plugin;
    private GameManager $gameManager;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->gameManager = $plugin->getGameManager();
    }

    /**
     * Cuando un jugador hace clic en el inventario del tablero
     */
    public function onInventoryTransaction(InventoryTransactionEvent $event): void {
        $transaction = $event->getTransaction();
        $player = $transaction->getSource();

        // Verificar si el jugador tiene una partida activa
        $game = $this->gameManager->getGameByPlayer($player);
        if ($game === null) return;

        foreach ($transaction->getActions() as $action) {
            if (!$action instanceof SlotChangeAction) continue;

            $slot = $action->getSlot();
            $inventory = $action->getInventory();

            // Solo procesar clics en el inventario del tablero
            if ($inventory === $game->getGui()->getInventory()) {
                $event->cancel();
                $game->getGui()->handleClick($player, $slot);
                return;
            }
        }
    }

    /**
     * Cuando un jugador se desconecta, guardar su partida
     */
    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $game = $this->gameManager->getGameByPlayer($player);

        if ($game !== null) {
            // Guardar partida automáticamente
            $this->gameManager->saveGame($game);
            $other = $game->getOpponent($player);
            if ($other !== null) {
                $other->sendMessage("§e♟ Tu oponente §c{$player->getName()} §ese desconectó. La partida fue guardada.");
            }
            $this->gameManager->removeGame($game);
        }

        // Remover espectadores
        $this->gameManager->removeSpectator($player);
    }
}
