<?php
declare(strict_types=1);

namespace chess\data;

use chess\Main;
use SQLite3;

/**
 * Gestiona la base de datos SQLite para ELO, partidas guardadas e historial.
 */
class DatabaseManager {

    private SQLite3 $db;

    public function __construct(Main $plugin) {
        $dataPath = $plugin->getDataFolder() . "chess.db";
        $this->db = new SQLite3($dataPath);
        $this->initTables();
    }

    private function initTables(): void {
        // Tabla de jugadores y ELO
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS players (
                name TEXT PRIMARY KEY,
                elo INTEGER DEFAULT 1000,
                wins INTEGER DEFAULT 0,
                losses INTEGER DEFAULT 0,
                draws INTEGER DEFAULT 0,
                games_played INTEGER DEFAULT 0
            )
        ");

        // Tabla de partidas guardadas
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS saved_games (
                id TEXT PRIMARY KEY,
                white TEXT NOT NULL,
                black TEXT NOT NULL,
                board_data TEXT NOT NULL,
                turn INTEGER NOT NULL,
                white_time INTEGER NOT NULL,
                black_time INTEGER NOT NULL,
                history TEXT NOT NULL,
                saved_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Tabla de historial de partidas
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS game_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                winner TEXT,
                loser TEXT,
                reason TEXT,
                played_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
    }

    // =====================
    // === ELO / RANKING ===
    // =====================

    public function getElo(string $playerName): int {
        $stmt = $this->db->prepare("SELECT elo FROM players WHERE name = :name");
        $stmt->bindValue(':name', $playerName);
        $result = $stmt->execute();
        $row = $result->fetchArray(SQLITE3_ASSOC);
        return $row ? (int)$row['elo'] : 1000;
    }

    public function setElo(string $playerName, int $elo): void {
        $this->ensurePlayer($playerName);
        $stmt = $this->db->prepare("UPDATE players SET elo = :elo WHERE name = :name");
        $stmt->bindValue(':elo', $elo);
        $stmt->bindValue(':name', $playerName);
        $stmt->execute();
    }

    public function saveGameResult(string $winner, string $loser, string $reason): void {
        $this->ensurePlayer($winner);
        $this->ensurePlayer($loser);

        // Incrementar victorias del ganador
        $stmt = $this->db->prepare("UPDATE players SET wins = wins + 1, games_played = games_played + 1 WHERE name = :name");
        $stmt->bindValue(':name', $winner);
        $stmt->execute();

        // Incrementar derrotas del perdedor
        $stmt = $this->db->prepare("UPDATE players SET losses = losses + 1, games_played = games_played + 1 WHERE name = :name");
        $stmt->bindValue(':name', $loser);
        $stmt->execute();

        // Registrar en historial
        $stmt = $this->db->prepare("INSERT INTO game_history (winner, loser, reason) VALUES (:w, :l, :r)");
        $stmt->bindValue(':w', $winner);
        $stmt->bindValue(':l', $loser);
        $stmt->bindValue(':r', $reason);
        $stmt->execute();
    }

    public function getTopPlayers(int $limit = 10): array {
        $result = $this->db->query("SELECT name, elo, wins, losses, draws FROM players ORDER BY elo DESC LIMIT $limit");
        $players = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $players[] = $row;
        }
        return $players;
    }

    private function ensurePlayer(string $name): void {
        $stmt = $this->db->prepare("INSERT OR IGNORE INTO players (name) VALUES (:name)");
        $stmt->bindValue(':name', $name);
        $stmt->execute();
    }

    // ======================
    // === PARTIDAS GUARD. ===
    // ======================

    public function saveGame(array $data): void {
        // Eliminar partida guardada anterior con el mismo id (o de los mismos jugadores)
        $stmt = $this->db->prepare("DELETE FROM saved_games WHERE (white = :w AND black = :b) OR (white = :b AND black = :w)");
        $stmt->bindValue(':w', $data['white']);
        $stmt->bindValue(':b', $data['black']);
        $stmt->execute();

        // Guardar nueva partida
        $stmt = $this->db->prepare("
            INSERT INTO saved_games (id, white, black, board_data, turn, white_time, black_time, history)
            VALUES (:id, :white, :black, :board, :turn, :wt, :bt, :history)
        ");
        $stmt->bindValue(':id', $data['id']);
        $stmt->bindValue(':white', $data['white']);
        $stmt->bindValue(':black', $data['black']);
        $stmt->bindValue(':board', json_encode($data['board']));
        $stmt->bindValue(':turn', $data['turn']);
        $stmt->bindValue(':wt', $data['whiteTime']);
        $stmt->bindValue(':bt', $data['blackTime']);
        $stmt->bindValue(':history', json_encode($data['history']));
        $stmt->execute();
    }

    public function getSavedGames(string $playerName): array {
        $stmt = $this->db->prepare("SELECT * FROM saved_games WHERE white = :name OR black = :name ORDER BY saved_at DESC");
        $stmt->bindValue(':name', $playerName);
        $result = $stmt->execute();

        $games = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $row['board'] = json_decode($row['board_data'], true);
            $row['history'] = json_decode($row['history'], true);
            $games[] = $row;
        }
        return $games;
    }

    public function deleteSavedGame(string $gameId): void {
        $stmt = $this->db->prepare("DELETE FROM saved_games WHERE id = :id");
        $stmt->bindValue(':id', $gameId);
        $stmt->execute();
    }

    public function close(): void {
        $this->db->close();
    }
}
