<?php
declare(strict_types=1);

namespace chess;

use chess\data\DatabaseManager;
use chess\game\GameManager;
use chess\tasks\TimerTask;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\event\Listener;

class Main extends PluginBase implements Listener {

    private static Main $instance;
    private GameManager $gameManager;
    private DatabaseManager $databaseManager;

    public function onEnable(): void {
        self::$instance = $this;

        // Guardar configuración por defecto
        $this->saveDefaultConfig();
        $this->saveResource("config.yml");

        // Inicializar base de datos y manager de partidas
        $this->databaseManager = new DatabaseManager($this);
        $this->gameManager = new GameManager($this);

        // Registrar eventos
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);

        // Tarea de temporizador (se ejecuta cada segundo)
        $this->getScheduler()->scheduleRepeatingTask(new TimerTask($this), 20);

        $this->getLogger()->info("§aChessPlugin activado correctamente.");
    }

    public function onDisable(): void {
        // Guardar todas las partidas activas antes de apagar
        $this->gameManager->saveAllGames();
        $this->databaseManager->close();
        $this->getLogger()->info("§cChessPlugin desactivado. Partidas guardadas.");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cEste comando solo se puede usar en el juego.");
            return true;
        }

        if (!isset($args[0])) {
            $this->sendHelp($sender);
            return true;
        }

        switch (strtolower($args[0])) {
            case "desafiar":
            case "challenge":
                if (!isset($args[1])) {
                    $sender->sendMessage("§cUso: /chess desafiar <jugador>");
                    return true;
                }
                $target = $this->getServer()->getPlayerByPrefix($args[1]);
                if ($target === null || $target === $sender) {
                    $sender->sendMessage("§cJugador no encontrado.");
                    return true;
                }
                $this->gameManager->sendChallenge($sender, $target);
                break;

            case "aceptar":
            case "accept":
                $this->gameManager->acceptChallenge($sender);
                break;

            case "rechazar":
            case "decline":
                $this->gameManager->declineChallenge($sender);
                break;

            case "espectador":
            case "spectate":
                if (!isset($args[1])) {
                    $sender->sendMessage("§cUso: /chess espectador <jugador>");
                    return true;
                }
                $target = $this->getServer()->getPlayerByPrefix($args[1]);
                if ($target === null) {
                    $sender->sendMessage("§cJugador no encontrado.");
                    return true;
                }
                $this->gameManager->addSpectator($sender, $target);
                break;

            case "ranking":
            case "elo":
                $this->gameManager->showRanking($sender);
                break;

            case "salir":
            case "resign":
                $this->gameManager->resignGame($sender);
                break;

            case "continuar":
            case "resume":
                $this->gameManager->showSavedGames($sender);
                break;

            default:
                $this->sendHelp($sender);
        }

        return true;
    }

    private function sendHelp(Player $player): void {
        $player->sendMessage("§6§l=== ChessPlugin ===");
        $player->sendMessage("§e/chess desafiar <jugador> §7- Desafiar a alguien");
        $player->sendMessage("§e/chess aceptar §7- Aceptar un desafío");
        $player->sendMessage("§e/chess rechazar §7- Rechazar un desafío");
        $player->sendMessage("§e/chess espectador <jugador> §7- Ver una partida");
        $player->sendMessage("§e/chess ranking §7- Ver el ranking ELO");
        $player->sendMessage("§e/chess continuar §7- Continuar partida guardada");
        $player->sendMessage("§e/chess salir §7- Rendirse en la partida actual");
    }

    public static function getInstance(): Main {
        return self::$instance;
    }

    public function getGameManager(): GameManager {
        return $this->gameManager;
    }

    public function getDatabaseManager(): DatabaseManager {
        return $this->databaseManager;
    }
}
