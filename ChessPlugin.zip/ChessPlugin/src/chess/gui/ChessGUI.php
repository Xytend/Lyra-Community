<?php
declare(strict_types=1);

namespace chess\gui;

use chess\game\ChessBoard;
use chess\game\ChessGame;
use pocketmine\inventory\SimpleInventory;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\item\ItemTypeIds;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

/**
 * GUI del tablero de ajedrez usando el inventario de Minecraft.
 * 
 * El tablero ocupa 8x8 = 64 slots del inventario.
 * Usamos un inventario de tamaño 90 (para dejar espacio a bordes y UI).
 * 
 * Layout del inventario (9 columnas):
 * Fila 0: [Info Blancas] [  ] [  ] [  ] [  ] [  ] [  ] [  ] [Info Negras]
 * Filas 1-8: Tablero de ajedrez
 * Fila 9: [Rendirse] [Guardar] [  ] [  ] [Tiempo B] [  ] [  ] [Guardar] [Salir]
 */
class ChessGUI {

    private ChessGame $game;
    private SimpleInventory $inventory;

    // Slot de selección actual
    private ?int $selectedSlot = null;
    private ?array $selectedPos = null; // [row, col]
    private array $highlightedSlots = [];

    public function __construct(ChessGame $game) {
        $this->game = $game;
        $this->inventory = new SimpleInventory(90);
    }

    /**
     * Construye/actualiza el tablero visualmente en el inventario.
     */
    public function buildBoard(): void {
        $board = $this->game->getBoard()->getBoard();

        // Construir el tablero fila por fila
        for ($row = 0; $row < 8; $row++) {
            for ($col = 0; $col < 8; $col++) {
                $slot = $this->posToSlot($row, $col);
                $piece = $board[$row][$col];
                $isLight = ($row + $col) % 2 === 0;
                $item = $this->getItemForPiece($piece, $isLight, $this->isHighlighted($slot));
                $this->inventory->setItem($slot, $item);
            }
        }

        // Barra de información superior
        $this->buildInfoBar();

        // Barra de acciones inferior
        $this->buildActionBar();
    }

    private function buildInfoBar(): void {
        $whiteName = $this->game->getWhite()->getName();
        $blackName = $this->game->getBlack()->getName();
        $wTime = $this->formatTime($this->game->getWhiteTime());
        $bTime = $this->formatTime($this->game->getBlackTime());
        $turn = $this->game->getCurrentTurn();

        // Slot 0: Info jugador blanco
        $whiteInfo = VanillaItems::PAPER();
        $whiteInfo->setCustomName(($turn === ChessBoard::WHITE ? "§f§l▶ " : "§7") . "♔ $whiteName");
        $whiteInfo->setLore(["§7Tiempo: §e$wTime", $turn === ChessBoard::WHITE ? "§a§lTu turno" : "§7Esperando..."]);
        $this->inventory->setItem(0, $whiteInfo);

        // Slot 8: Info jugador negro
        $blackInfo = VanillaItems::PAPER();
        $blackInfo->setCustomName(($turn === ChessBoard::BLACK ? "§8§l▶ " : "§7") . "♚ $blackName");
        $blackInfo->setLore(["§7Tiempo: §e$bTime", $turn === ChessBoard::BLACK ? "§a§lTu turno" : "§7Esperando..."]);
        $this->inventory->setItem(8, $blackInfo);

        // Slots 1-7: Decoración
        $glass = VanillaItems::GLASS_PANE();
        $glass->setCustomName("§r");
        for ($i = 1; $i <= 7; $i++) {
            if ($i !== 4) $this->inventory->setItem($i, clone $glass);
        }

        // Slot 4: Turno actual
        $turnItem = VanillaItems::COMPASS();
        $turnItem->setCustomName("§e§lTurno Actual");
        $turnItem->setLore([$turn === ChessBoard::WHITE ? "§f♔ Blancas" : "§8♚ Negras"]);
        $this->inventory->setItem(4, $turnItem);
    }

    private function buildActionBar(): void {
        $baseSlot = 81; // Última fila

        // Rendirse
        $resign = VanillaItems::REDSTONE();
        $resign->setCustomName("§c§lRendirse");
        $resign->setLore(["§7Haz clic para rendirte", "§cPerderás la partida y ELO"]);
        $this->inventory->setItem($baseSlot, $resign);

        // Guardar partida
        $save = VanillaItems::BOOK();
        $save->setCustomName("§e§lGuardar y Salir");
        $save->setLore(["§7La partida se guardará", "§apuedes continuarla después"]);
        $this->inventory->setItem($baseSlot + 1, $save);

        // Separadores
        $glass = VanillaItems::GLASS_PANE();
        $glass->setCustomName("§r");
        for ($i = 2; $i <= 8; $i++) {
            $this->inventory->setItem($baseSlot + $i, clone $glass);
        }
    }

    /**
     * Maneja el clic de un jugador en un slot del inventario.
     */
    public function handleClick(Player $player, int $slot): void {
        // Verificar si es la barra de acciones
        if ($slot >= 81) {
            $this->handleActionClick($player, $slot);
            return;
        }

        // Ignorar barra de información
        if ($slot < 9) return;

        $pos = $this->slotToPos($slot);
        if ($pos === null) return;

        [$row, $col] = $pos;
        $board = $this->game->getBoard();
        $playerColor = $this->game->getPlayerColor($player);

        // Si hay pieza seleccionada, intentar mover
        if ($this->selectedPos !== null) {
            [$selRow, $selCol] = $this->selectedPos;

            // Clic en casilla resaltada = mover
            if ($this->isHighlighted($slot)) {
                $this->clearSelection();
                $this->game->attemptMove($player, $selRow, $selCol, $row, $col);
                return;
            }

            // Clic en otra pieza propia = re-seleccionar
            $clickedColor = $board->getColor($row, $col);
            if ($clickedColor === $playerColor) {
                $this->clearSelection();
                $this->selectPiece($player, $row, $col, $slot);
                return;
            }

            // Clic en vacío o pieza enemiga sin resaltar = deseleccionar
            $this->clearSelection();
            $this->buildBoard();
            return;
        }

        // Sin selección: seleccionar pieza
        $pieceColor = $board->getColor($row, $col);
        if ($pieceColor === ChessBoard::WHITE && $playerColor !== ChessBoard::WHITE) {
            $player->sendMessage("§cEsa es la pieza del oponente.");
            return;
        }
        if ($pieceColor === ChessBoard::BLACK && $playerColor !== ChessBoard::BLACK) {
            $player->sendMessage("§cEsa es la pieza del oponente.");
            return;
        }
        if ($pieceColor === 0) {
            $player->sendMessage("§cCasilla vacía.");
            return;
        }

        $this->selectPiece($player, $row, $col, $slot);
    }

    private function selectPiece(Player $player, int $row, int $col, int $slot): void {
        $validMoves = $this->game->getBoard()->getValidMoves($row, $col);

        if (empty($validMoves)) {
            $player->sendMessage("§cEsa pieza no tiene movimientos válidos.");
            return;
        }

        $this->selectedPos = [$row, $col];
        $this->selectedSlot = $slot;
        $this->highlightedSlots = [];

        foreach ($validMoves as $move) {
            $this->highlightedSlots[] = $this->posToSlot($move[0], $move[1]);
        }

        $this->buildBoard();
        $pieceName = $this->getPieceName(abs($this->game->getBoard()->getPiece($row, $col)));
        $player->sendMessage("§a{$pieceName} seleccionado. Haz clic en una casilla resaltada para mover.");
    }

    private function clearSelection(): void {
        $this->selectedPos = null;
        $this->selectedSlot = null;
        $this->highlightedSlots = [];
    }

    private function isHighlighted(int $slot): bool {
        return in_array($slot, $this->highlightedSlots, true);
    }

    private function handleActionClick(Player $player, int $slot): void {
        $game = \chess\Main::getInstance()->getGameManager()->getGameByPlayer($player);
        if ($game === null) return;

        if ($slot === 81) { // Rendirse
            \chess\Main::getInstance()->getGameManager()->resignGame($player);
        } elseif ($slot === 82) { // Guardar y salir
            \chess\Main::getInstance()->getGameManager()->saveGame($game);
            $opponent = $game->getOpponent($player);
            $player->sendMessage("§aPartida guardada. Puedes continuarla con /chess continuar");
            $opponent?->sendMessage("§e{$player->getName()} guardó y salió de la partida.");
            \chess\Main::getInstance()->getGameManager()->removeGame($game);
        }
    }

    /**
     * Convierte posición del tablero [row, col] a slot del inventario.
     * Fila 0 del tablero = fila 1 del inventario (saltamos la barra de info).
     */
    private function posToSlot(int $row, int $col): int {
        return ($row + 1) * 9 + $col;
    }

    /**
     * Convierte slot del inventario a posición del tablero [row, col].
     */
    private function slotToPos(int $slot): ?array {
        $row = (int)($slot / 9) - 1;
        $col = $slot % 9;
        if ($row < 0 || $row > 7 || $col > 7) return null;
        return [$row, $col];
    }

    /**
     * Retorna el Item de Minecraft que representa una pieza de ajedrez.
     */
    private function getItemForPiece(int $piece, bool $isLight, bool $highlighted): Item {
        $color = $piece <=> 0; // -1, 0, o 1
        $type = abs($piece);

        // Casilla resaltada (movimiento posible)
        if ($highlighted && $piece === ChessBoard::EMPTY) {
            $item = VanillaItems::LIME_DYE();
            $item->setCustomName("§a● Mover aquí");
            return $item;
        }

        // Casilla con pieza resaltada (captura posible)
        if ($highlighted && $piece !== ChessBoard::EMPTY) {
            $item = $this->getPieceItem($type, $color);
            // Se añade indicador de captura
            $lore = $item->getLore();
            $lore[] = "§c⚔ Capturar";
            $item->setLore($lore);
            return $item;
        }

        // Casilla vacía
        if ($piece === ChessBoard::EMPTY) {
            $item = $isLight ? VanillaItems::BONE_MEAL() : VanillaItems::INK_SAC();
            $item->setCustomName("§r");
            return $item;
        }

        // Pieza normal
        return $this->getPieceItem($type, $color);
    }

    private function getPieceItem(int $type, int $color): Item {
        $isWhite = $color === ChessBoard::WHITE;
        $colorPrefix = $isWhite ? "§f" : "§8";
        $name = $this->getPieceName($type);
        $symbol = $this->getPieceSymbol($type, $isWhite);

        // Elegir item de Minecraft según pieza
        $item = match($type) {
            ChessBoard::KING   => $isWhite ? VanillaItems::GOLDEN_SWORD() : VanillaItems::IRON_SWORD(),
            ChessBoard::QUEEN  => $isWhite ? VanillaItems::GOLDEN_HOE() : VanillaItems::IRON_HOE(),
            ChessBoard::ROOK   => $isWhite ? VanillaItems::GOLDEN_PICKAXE() : VanillaItems::IRON_PICKAXE(),
            ChessBoard::BISHOP => $isWhite ? VanillaItems::GOLDEN_AXE() : VanillaItems::IRON_AXE(),
            ChessBoard::KNIGHT => $isWhite ? VanillaItems::GOLDEN_SHOVEL() : VanillaItems::IRON_SHOVEL(),
            ChessBoard::PAWN   => $isWhite ? VanillaItems::BONE() : VanillaItems::STICK(),
            default            => VanillaItems::BARRIER()
        };

        $item->setCustomName("{$colorPrefix}§l{$symbol} {$name}");
        $item->setLore(["§7" . ($isWhite ? "Pieza Blanca" : "Pieza Negra")]);
        return $item;
    }

    private function getPieceName(int $type): string {
        return match($type) {
            ChessBoard::KING   => "Rey",
            ChessBoard::QUEEN  => "Reina",
            ChessBoard::ROOK   => "Torre",
            ChessBoard::BISHOP => "Alfil",
            ChessBoard::KNIGHT => "Caballo",
            ChessBoard::PAWN   => "Peón",
            default            => "?"
        };
    }

    private function getPieceSymbol(int $type, bool $white): string {
        $symbols = [
            ChessBoard::KING   => $white ? "♔" : "♚",
            ChessBoard::QUEEN  => $white ? "♕" : "♛",
            ChessBoard::ROOK   => $white ? "♖" : "♜",
            ChessBoard::BISHOP => $white ? "♗" : "♝",
            ChessBoard::KNIGHT => $white ? "♘" : "♞",
            ChessBoard::PAWN   => $white ? "♙" : "♟",
        ];
        return $symbols[$type] ?? "?";
    }

    private function formatTime(int $seconds): string {
        $min = (int)($seconds / 60);
        $sec = $seconds % 60;
        return sprintf("%d:%02d", $min, $sec);
    }

    public function getInventory(): SimpleInventory {
        return $this->inventory;
    }
}
