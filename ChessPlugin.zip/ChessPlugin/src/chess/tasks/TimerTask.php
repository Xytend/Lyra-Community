<?php
declare(strict_types=1);

namespace chess\tasks;

use chess\Main;
use pocketmine\scheduler\Task;

/**
 * Tarea que se ejecuta cada segundo para actualizar los temporizadores de las partidas.
 */
class TimerTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        foreach ($this->plugin->getGameManager()->getActiveGames() as $game) {
            if ($game->isActive()) {
                $game->tickTimer();
                // Actualizar la GUI con los tiempos nuevos cada 5 segundos
                // (para no sobrecargar el servidor actualizando cada tick)
                if (time() % 5 === 0) {
                    $game->getGui()->buildBoard();
                }
            }
        }
    }
}
