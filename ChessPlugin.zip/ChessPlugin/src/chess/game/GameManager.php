<?php
declare(strict_types=1);

namespace chess\game;

use chess\Main;
use pocketmine\player\Player;

/**
 * Gestiona todas las partidas activas, desafíos y espectadores.
 */
class GameManager {

    private Main $plugin;
    /** @var ChessGame[] */
    private array $activeGames = [];
    /** @var array Desafíos pendientes [desafiado => desafiante] */
    private array $pendingChallenges = [];
    /** @var array Espectadores [espectadorName => gameid] */
    private array $spectatorMap = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function sendChallenge(Player $challenger, Player $target): void {
        // Verificar que ninguno esté ya en una partida
        if ($this->getGameByPlayer($challenger) !== null) {
            $challenger->sendMessage("§cYa estás en una partida.");
            return;
        }
        if ($this->getGameByPlayer($target) !== null) {
            $challenger->sendMessage("§c{$target->getName()} ya está en una partida.");
            return;
        }

        $this->pendingChallenges[$target->getName()] = $challenger->getName();

        $challenger->sendMessage("§e♟ Desafío enviado a §a{$target->getName()}§e. Esperando respuesta...");
        $target->sendMessage("§a♟ §e{$challenger->getName()} §ate desafía al ajedrez!");
        $target->sendMessage("§7Usa §e/chess aceptar §7o §e/chess rechazar");

        // Auto-cancelar desafío después de 30 segundos
        $this->plugin->getScheduler()->scheduleDelayedTask(
            new \pocketmine\scheduler\ClosureTask(function() use ($target, $challenger): void {
                if (isset($this->pendingChallenges[$target->getName()])) {
                    unset($this->pendingChallenges[$target->getName()]);
                    if ($challenger->isOnline()) $challenger->sendMessage("§cDesafío expirado.");
                    if ($target->isOnline()) $target->sendMessage("§cDesafío de {$challenger->getName()} expirado.");
                }
            }),
            600 // 30 segundos
        );
    }

    public function acceptChallenge(Player $player): void {
        if (!isset($this->pendingChallenges[$player->getName()])) {
            $player->sendMessage("§cNo tienes desafíos pendientes.");
            return;
        }

        $challengerName = $this->pendingChallenges[$player->getName()];
        unset($this->pendingChallenges[$player->getName()]);

        $challenger = $this->plugin->getServer()->getPlayerExact($challengerName);
        if ($challenger === null || !$challenger->isOnline()) {
            $player->sendMessage("§cEl jugador ya no está conectado.");
            return;
        }

        $timePerPlayer = (int)$this->plugin->getConfig()->get("time_per_player", 300);
        $game = new ChessGame($challenger, $player, $timePerPlayer);
        $this->activeGames[$game->getId()] = $game;

        $challenger->sendMessage("§a♟ ¡La partida ha comenzado! Tú juegas con las §fPiezas Blancas§a.");
        $player->sendMessage("§a♟ ¡La partida ha comenzado! Tú juegas con las §8Piezas Negras§a.");
    }

    public function declineChallenge(Player $player): void {
        if (!isset($this->pendingChallenges[$player->getName()])) {
            $player->sendMessage("§cNo tienes desafíos pendientes.");
            return;
        }

        $challengerName = $this->pendingChallenges[$player->getName()];
        unset($this->pendingChallenges[$player->getName()]);

        $challenger = $this->plugin->getServer()->getPlayerExact($challengerName);
        $challenger?->sendMessage("§c{$player->getName()} rechazó tu desafío.");
        $player->sendMessage("§eRechazaste el desafío de {$challengerName}.");
    }

    public function addSpectator(Player $spectator, Player $target): void {
        $game = $this->getGameByPlayer($target);
        if ($game === null) {
            $spectator->sendMessage("§c{$target->getName()} no está en una partida.");
            return;
        }

        if ($game->hasPlayer($spectator)) {
            $spectator->sendMessage("§cNo puedes espectarte a ti mismo.");
            return;
        }

        $this->spectatorMap[$spectator->getName()] = $game->getId();
        $game->addSpectator($spectator);
    }

    public function removeSpectator(Player $spectator): void {
        if (isset($this->spectatorMap[$spectator->getName()])) {
            $gameId = $this->spectatorMap[$spectator->getName()];
            $this->activeGames[$gameId]?->removeSpectator($spectator);
            unset($this->spectatorMap[$spectator->getName()]);
        }
    }

    public function resignGame(Player $player): void {
        $game = $this->getGameByPlayer($player);
        if ($game === null) {
            $player->sendMessage("§cNo estás en ninguna partida.");
            return;
        }

        $opponent = $game->getOpponent($player);
        $player->sendMessage("§cTe has rendido. Perdiste la partida.");
        $opponent?->sendMessage("§a¡Tu oponente se rindió! ¡Ganaste!");

        $this->processGameEnd($game, $opponent, $player, "resign");
        $this->removeGame($game);
    }

    public function processGameEnd(ChessGame $game, ?Player $winner, ?Player $loser, string $reason): void {
        $db = $this->plugin->getDatabaseManager();

        if ($winner !== null && $loser !== null) {
            // Calcular nuevo ELO
            $winnerElo = $db->getElo($winner->getName());
            $loserElo = $db->getElo($loser->getName());
            [$newWinnerElo, $newLoserElo] = $this->calculateElo($winnerElo, $loserElo);

            $db->setElo($winner->getName(), $newWinnerElo);
            $db->setElo($loser->getName(), $newLoserElo);
            $db->saveGameResult($winner->getName(), $loser->getName(), $reason);

            $winner->sendMessage("§6ELO: §a+".($newWinnerElo - $winnerElo)." §7(Total: §e{$newWinnerElo}§7)");
            $loser->sendMessage("§6ELO: §c".($newLoserElo - $loserElo)." §7(Total: §e{$newLoserElo}§7)");
        } elseif ($reason === "stalemate") {
            // Empate: ELO sin cambio o pequeño ajuste
            if ($winner === null) {
                // Ambos mantienen ELO en empate
                $game->getWhite()->sendMessage("§eEmpate: ELO sin cambios.");
                $game->getBlack()->sendMessage("§eEmpate: ELO sin cambios.");
            }
        }

        $this->removeGame($game);
    }

    /**
     * Calcula nuevo ELO usando fórmula estándar (K=32).
     * @return array [nuevoEloGanador, nuevoEloPerdedor]
     */
    private function calculateElo(int $winnerElo, int $loserElo): array {
        $k = 32;
        $expectedWinner = 1 / (1 + pow(10, ($loserElo - $winnerElo) / 400));
        $expectedLoser = 1 - $expectedWinner;

        $newWinner = (int)round($winnerElo + $k * (1 - $expectedWinner));
        $newLoser = (int)round($loserElo + $k * (0 - $expectedLoser));

        return [$newWinner, $newLoser];
    }

    public function showRanking(Player $player): void {
        $ranking = $this->plugin->getDatabaseManager()->getTopPlayers(10);
        $player->sendMessage("§6§l=== Ranking ELO de Ajedrez ===");
        foreach ($ranking as $i => $entry) {
            $pos = $i + 1;
            $medal = match($pos) {
                1 => "§6🥇",
                2 => "§7🥈",
                3 => "§c🥉",
                default => "§7#{$pos}"
            };
            $player->sendMessage("$medal §e{$entry['name']} §7- §aELO: {$entry['elo']} §7(G:{$entry['wins']} P:{$entry['losses']})");
        }
    }

    public function showSavedGames(Player $player): void {
        $saved = $this->plugin->getDatabaseManager()->getSavedGames($player->getName());
        if (empty($saved)) {
            $player->sendMessage("§cNo tienes partidas guardadas.");
            return;
        }
        $player->sendMessage("§6§l=== Partidas Guardadas ===");
        foreach ($saved as $i => $game) {
            $opponent = $game['white'] === $player->getName() ? $game['black'] : $game['white'];
            $player->sendMessage("§e#{$i} §avs {$opponent} §7| §fTurno: ".($game['turn'] === 1 ? "Blancas" : "Negras"));
        }
        $player->sendMessage("§7Usa §e/chess continuar <número> §7para reanudar.");
    }

    public function saveGame(ChessGame $game): void {
        $this->plugin->getDatabaseManager()->saveGame($game->toSaveData());
    }

    public function saveAllGames(): void {
        foreach ($this->activeGames as $game) {
            if ($game->isActive()) {
                $this->saveGame($game);
            }
        }
    }

    public function removeGame(ChessGame $game): void {
        unset($this->activeGames[$game->getId()]);
    }

    public function getGameByPlayer(Player $player): ?ChessGame {
        foreach ($this->activeGames as $game) {
            if ($game->hasPlayer($player)) return $game;
        }
        return null;
    }

    /** @return ChessGame[] */
    public function getActiveGames(): array {
        return $this->activeGames;
    }
}
