<?php
declare(strict_types=1);

namespace chess\game;

use chess\gui\ChessGUI;
use pocketmine\player\Player;

/**
 * Representa una partida de ajedrez entre dos jugadores.
 */
class ChessGame {

    private string $id;
    private Player $white;
    private Player $black;
    private ChessBoard $board;
    private ChessGUI $gui;
    private int $currentTurn; // ChessBoard::WHITE o ChessBoard::BLACK
    private int $whiteTime;   // Segundos restantes blancas
    private int $blackTime;   // Segundos restantes negras
    private array $moveHistory = [];
    private array $spectators = [];
    private bool $active = true;

    public function __construct(Player $white, Player $black, int $timePerPlayer = 300, ?array $savedData = null) {
        $this->id = uniqid("game_", true);
        $this->white = $white;
        $this->black = $black;
        $this->board = new ChessBoard();
        $this->whiteTime = $timePerPlayer;
        $this->blackTime = $timePerPlayer;
        $this->currentTurn = ChessBoard::WHITE;

        if ($savedData !== null) {
            $this->loadFromData($savedData);
        }

        $this->gui = new ChessGUI($this);

        // Abrir inventario a ambos jugadores
        $this->openGUIForBoth();
    }

    private function openGUIForBoth(): void {
        $this->gui->buildBoard();
        $this->white->sendInventory($this->gui->getInventory());
        $this->black->sendInventory($this->gui->getInventory());
        $this->notifyTurn();
    }

    /**
     * Intenta hacer un movimiento. Retorna true si fue válido.
     */
    public function attemptMove(Player $player, int $fromRow, int $fromCol, int $toRow, int $toCol): bool {
        // Verificar que sea el turno del jugador
        $playerColor = $this->getPlayerColor($player);
        if ($playerColor !== $this->currentTurn) {
            $player->sendMessage("§c¡No es tu turno!");
            return false;
        }

        // Verificar que la pieza sea del color correcto
        if ($this->board->getColor($fromRow, $fromCol) !== $playerColor) {
            $player->sendMessage("§cEsa no es tu pieza.");
            return false;
        }

        // Verificar que el movimiento sea válido
        $validMoves = $this->board->getValidMoves($fromRow, $fromCol);
        $isValid = false;
        foreach ($validMoves as $move) {
            if ($move[0] === $toRow && $move[1] === $toCol) {
                $isValid = true;
                break;
            }
        }

        if (!$isValid) {
            $player->sendMessage("§cMovimiento inválido.");
            return false;
        }

        // Ejecutar movimiento
        $result = $this->board->makeMove($fromRow, $fromCol, $toRow, $toCol);

        // Registrar en historial
        $this->moveHistory[] = [
            'from' => [$fromRow, $fromCol],
            'to' => [$toRow, $toCol],
            'player' => $player->getName(),
            'result' => $result
        ];

        // Cambiar turno
        $this->currentTurn = -$this->currentTurn;

        // Notificar resultado
        $this->handleMoveResult($result, $player);

        // Actualizar GUI para todos
        $this->gui->buildBoard();
        $this->updateAllGUIs();

        return true;
    }

    private function handleMoveResult(string $result, Player $mover): void {
        $opponent = $this->getOpponent($mover);

        switch ($result) {
            case "check":
                $mover->sendMessage("§a¡Jaque!");
                $opponent?->sendMessage("§c¡Estás en jaque!");
                $this->notifySpectators("§e{$mover->getName()} da jaque.");
                break;
            case "checkmate":
                $mover->sendMessage("§a§l¡JAQUE MATE! ¡Ganaste!");
                $opponent?->sendMessage("§c§lJaque mate. Perdiste.");
                $this->notifySpectators("§6§l¡Jaque Mate! {$mover->getName()} gana.");
                $this->endGame($mover, $opponent, "checkmate");
                break;
            case "stalemate":
                $mover->sendMessage("§e¡Ahogado! Es un empate.");
                $opponent?->sendMessage("§e¡Ahogado! Es un empate.");
                $this->notifySpectators("§e¡Ahogado! La partida termina en empate.");
                $this->endGame(null, null, "stalemate");
                break;
            case "promotion":
                $mover->sendMessage("§a¡Promoción! Tu peón se convirtió en Reina.");
                break;
            default:
                $this->notifyTurn();
        }
    }

    private function endGame(?Player $winner, ?Player $loser, string $reason): void {
        $this->active = false;

        // Actualizar ELO
        \chess\Main::getInstance()->getGameManager()->processGameEnd($this, $winner, $loser, $reason);
    }

    private function notifyTurn(): void {
        $current = $this->currentTurn === ChessBoard::WHITE ? $this->white : $this->black;
        $opponent = $this->getOpponent($current);

        $current->sendMessage("§a♟ §lEs tu turno. §r§7(" . $this->getTimeString($current) . " restantes)");
        $opponent?->sendMessage("§7⌛ Turno de §e{$current->getName()}");
    }

    public function tickTimer(): void {
        if (!$this->active) return;

        if ($this->currentTurn === ChessBoard::WHITE) {
            $this->whiteTime--;
            if ($this->whiteTime <= 0) {
                $this->white->sendMessage("§c¡Se acabó tu tiempo! Perdiste.");
                $this->black->sendMessage("§a¡Tu oponente se quedó sin tiempo! ¡Ganaste!");
                $this->endGame($this->black, $this->white, "timeout");
            } elseif ($this->whiteTime <= 30) {
                $this->white->sendMessage("§c⚠ ¡Solo quedan {$this->whiteTime} segundos!");
            }
        } else {
            $this->blackTime--;
            if ($this->blackTime <= 0) {
                $this->black->sendMessage("§c¡Se acabó tu tiempo! Perdiste.");
                $this->white->sendMessage("§a¡Tu oponente se quedó sin tiempo! ¡Ganaste!");
                $this->endGame($this->white, $this->black, "timeout");
            } elseif ($this->blackTime <= 30) {
                $this->black->sendMessage("§c⚠ ¡Solo quedan {$this->blackTime} segundos!");
            }
        }
    }

    private function getTimeString(Player $player): string {
        $seconds = $this->getPlayerColor($player) === ChessBoard::WHITE ? $this->whiteTime : $this->blackTime;
        $min = (int)($seconds / 60);
        $sec = $seconds % 60;
        return sprintf("%d:%02d", $min, $sec);
    }

    public function addSpectator(Player $spectator): void {
        $this->spectators[$spectator->getName()] = $spectator;
        $spectator->sendInventory($this->gui->getInventory());
        $spectator->sendMessage("§e♟ Estás viendo la partida: §a{$this->white->getName()} §evs §c{$this->black->getName()}");
    }

    public function removeSpectator(Player $spectator): void {
        unset($this->spectators[$spectator->getName()]);
    }

    private function notifySpectators(string $message): void {
        foreach ($this->spectators as $spectator) {
            if ($spectator->isOnline()) {
                $spectator->sendMessage($message);
            }
        }
    }

    private function updateAllGUIs(): void {
        $inv = $this->gui->getInventory();
        $this->white->sendInventory($inv);
        $this->black->sendInventory($inv);
        foreach ($this->spectators as $spectator) {
            if ($spectator->isOnline()) $spectator->sendInventory($inv);
        }
    }

    public function getPlayerColor(Player $player): int {
        return $player->getName() === $this->white->getName() ? ChessBoard::WHITE : ChessBoard::BLACK;
    }

    public function getOpponent(Player $player): ?Player {
        if ($player->getName() === $this->white->getName()) {
            return $this->black->isOnline() ? $this->black : null;
        }
        return $this->white->isOnline() ? $this->white : null;
    }

    public function hasPlayer(Player $player): bool {
        return $player->getName() === $this->white->getName() ||
               $player->getName() === $this->black->getName();
    }

    public function toSaveData(): array {
        return [
            'id' => $this->id,
            'white' => $this->white->getName(),
            'black' => $this->black->getName(),
            'board' => $this->board->toArray(),
            'turn' => $this->currentTurn,
            'whiteTime' => $this->whiteTime,
            'blackTime' => $this->blackTime,
            'history' => $this->moveHistory,
        ];
    }

    private function loadFromData(array $data): void {
        $this->id = $data['id'];
        $this->board->fromArray($data['board']);
        $this->currentTurn = $data['turn'];
        $this->whiteTime = $data['whiteTime'];
        $this->blackTime = $data['blackTime'];
        $this->moveHistory = $data['history'];
    }

    // Getters
    public function getId(): string { return $this->id; }
    public function getWhite(): Player { return $this->white; }
    public function getBlack(): Player { return $this->black; }
    public function getBoard(): ChessBoard { return $this->board; }
    public function getGui(): ChessGUI { return $this->gui; }
    public function getCurrentTurn(): int { return $this->currentTurn; }
    public function isActive(): bool { return $this->active; }
    public function getWhiteTime(): int { return $this->whiteTime; }
    public function getBlackTime(): int { return $this->blackTime; }
}
