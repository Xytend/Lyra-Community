<?php
declare(strict_types=1);

namespace chess\game;

/**
 * Clase que representa el tablero de ajedrez y toda la lógica de movimientos.
 * 
 * El tablero es un array de 8x8. Cada celda contiene:
 * - 0: vacío
 * - Número positivo: pieza blanca
 * - Número negativo: pieza negra
 * 
 * Piezas: 1=Peón, 2=Torre, 3=Caballo, 4=Alfil, 5=Reina, 6=Rey
 */
class ChessBoard {

    // Constantes de piezas
    const EMPTY  = 0;
    const PAWN   = 1;
    const ROOK   = 2;
    const KNIGHT = 3;
    const BISHOP = 4;
    const QUEEN  = 5;
    const KING   = 6;

    const WHITE  = 1;
    const BLACK  = -1;

    /** @var int[][] Tablero 8x8 */
    private array $board;

    /** Estado especial: si algún peón puede ser capturado al paso */
    private ?array $enPassantTarget = null;

    /** Derechos de enroque: [blancoReyLado, blancoReinaLado, negroReyLado, negroReinaLado] */
    private array $castlingRights = [true, true, true, true];

    public function __construct() {
        $this->initBoard();
    }

    /**
     * Inicializa el tablero con la posición estándar de ajedrez.
     */
    public function initBoard(): void {
        $this->board = array_fill(0, 8, array_fill(0, 8, self::EMPTY));

        // Piezas negras (fila 0 y 1)
        $backRow = [self::ROOK, self::KNIGHT, self::BISHOP, self::QUEEN, self::KING, self::BISHOP, self::KNIGHT, self::ROOK];
        for ($col = 0; $col < 8; $col++) {
            $this->board[0][$col] = -$backRow[$col];
            $this->board[1][$col] = -self::PAWN;
        }

        // Piezas blancas (fila 6 y 7)
        for ($col = 0; $col < 8; $col++) {
            $this->board[6][$col] = self::PAWN;
            $this->board[7][$col] = $backRow[$col];
        }
    }

    /**
     * Obtiene la pieza en una posición del tablero.
     */
    public function getPiece(int $row, int $col): int {
        return $this->board[$row][$col] ?? self::EMPTY;
    }

    /**
     * Obtiene el color de la pieza en una posición (1=blanco, -1=negro, 0=vacío)
     */
    public function getColor(int $row, int $col): int {
        $piece = $this->getPiece($row, $col);
        return $piece <=> 0; // retorna -1, 0 o 1
    }

    /**
     * Obtiene todos los movimientos válidos de una pieza.
     * @return array Lista de [row, col] destino
     */
    public function getValidMoves(int $row, int $col): array {
        $piece = $this->getPiece($row, $col);
        if ($piece === self::EMPTY) return [];

        $color = $this->getColor($row, $col);
        $rawMoves = $this->getRawMoves($row, $col, abs($piece), $color);

        // Filtrar movimientos que dejen al rey en jaque
        $validMoves = [];
        foreach ($rawMoves as $move) {
            if (!$this->wouldLeaveKingInCheck($row, $col, $move[0], $move[1], $color)) {
                $validMoves[] = $move;
            }
        }

        return $validMoves;
    }

    /**
     * Obtiene los movimientos crudos sin verificar jaques.
     */
    private function getRawMoves(int $row, int $col, int $pieceType, int $color): array {
        $moves = [];

        switch ($pieceType) {
            case self::PAWN:
                $moves = $this->getPawnMoves($row, $col, $color);
                break;
            case self::ROOK:
                $moves = $this->getSlidingMoves($row, $col, $color, [[0,1],[0,-1],[1,0],[-1,0]]);
                break;
            case self::KNIGHT:
                $moves = $this->getKnightMoves($row, $col, $color);
                break;
            case self::BISHOP:
                $moves = $this->getSlidingMoves($row, $col, $color, [[1,1],[1,-1],[-1,1],[-1,-1]]);
                break;
            case self::QUEEN:
                $moves = $this->getSlidingMoves($row, $col, $color, [[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]]);
                break;
            case self::KING:
                $moves = $this->getKingMoves($row, $col, $color);
                break;
        }

        return $moves;
    }

    private function getPawnMoves(int $row, int $col, int $color): array {
        $moves = [];
        $dir = $color === self::WHITE ? -1 : 1; // Blancos suben (row decrece), negros bajan
        $startRow = $color === self::WHITE ? 6 : 1;

        // Avance simple
        $newRow = $row + $dir;
        if ($this->isInBounds($newRow, $col) && $this->getPiece($newRow, $col) === self::EMPTY) {
            $moves[] = [$newRow, $col];
            // Avance doble desde posición inicial
            if ($row === $startRow) {
                $doubleRow = $row + 2 * $dir;
                if ($this->getPiece($doubleRow, $col) === self::EMPTY) {
                    $moves[] = [$doubleRow, $col];
                }
            }
        }

        // Capturas diagonales
        foreach ([-1, 1] as $dCol) {
            $captureCol = $col + $dCol;
            if ($this->isInBounds($newRow, $captureCol)) {
                if ($this->getColor($newRow, $captureCol) === -$color) {
                    $moves[] = [$newRow, $captureCol];
                }
                // Captura al paso
                if ($this->enPassantTarget !== null &&
                    $this->enPassantTarget[0] === $newRow &&
                    $this->enPassantTarget[1] === $captureCol) {
                    $moves[] = [$newRow, $captureCol];
                }
            }
        }

        return $moves;
    }

    private function getKnightMoves(int $row, int $col, int $color): array {
        $moves = [];
        $jumps = [[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]];
        foreach ($jumps as [$dr, $dc]) {
            $r = $row + $dr;
            $c = $col + $dc;
            if ($this->isInBounds($r, $c) && $this->getColor($r, $c) !== $color) {
                $moves[] = [$r, $c];
            }
        }
        return $moves;
    }

    private function getSlidingMoves(int $row, int $col, int $color, array $directions): array {
        $moves = [];
        foreach ($directions as [$dr, $dc]) {
            $r = $row + $dr;
            $c = $col + $dc;
            while ($this->isInBounds($r, $c)) {
                $targetColor = $this->getColor($r, $c);
                if ($targetColor === $color) break; // Bloqueado por pieza propia
                $moves[] = [$r, $c];
                if ($targetColor === -$color) break; // Captura, no continuar
                $r += $dr;
                $c += $dc;
            }
        }
        return $moves;
    }

    private function getKingMoves(int $row, int $col, int $color): array {
        $moves = [];
        for ($dr = -1; $dr <= 1; $dr++) {
            for ($dc = -1; $dc <= 1; $dc++) {
                if ($dr === 0 && $dc === 0) continue;
                $r = $row + $dr;
                $c = $col + $dc;
                if ($this->isInBounds($r, $c) && $this->getColor($r, $c) !== $color) {
                    $moves[] = [$r, $c];
                }
            }
        }

        // Enroque
        $backRow = $color === self::WHITE ? 7 : 0;
        if ($row === $backRow && $col === 4) {
            // Enroque lado rey
            $kingSide = $color === self::WHITE ? 0 : 2;
            if ($this->castlingRights[$kingSide] &&
                $this->getPiece($backRow, 5) === self::EMPTY &&
                $this->getPiece($backRow, 6) === self::EMPTY &&
                !$this->isSquareAttacked($backRow, 4, -$color) &&
                !$this->isSquareAttacked($backRow, 5, -$color)) {
                $moves[] = [$backRow, 6];
            }
            // Enroque lado reina
            $queenSide = $color === self::WHITE ? 1 : 3;
            if ($this->castlingRights[$queenSide] &&
                $this->getPiece($backRow, 3) === self::EMPTY &&
                $this->getPiece($backRow, 2) === self::EMPTY &&
                $this->getPiece($backRow, 1) === self::EMPTY &&
                !$this->isSquareAttacked($backRow, 4, -$color) &&
                !$this->isSquareAttacked($backRow, 3, -$color)) {
                $moves[] = [$backRow, 2];
            }
        }

        return $moves;
    }

    /**
     * Ejecuta un movimiento en el tablero.
     * @return string Resultado especial: "promotion", "check", "checkmate", "stalemate", ""
     */
    public function makeMove(int $fromRow, int $fromCol, int $toRow, int $toCol): string {
        $piece = $this->getPiece($fromRow, $fromCol);
        $color = $this->getColor($fromRow, $fromCol);

        // Resetear captura al paso
        $this->enPassantTarget = null;

        // Mover pieza
        $this->board[$toRow][$toCol] = $piece;
        $this->board[$fromRow][$fromCol] = self::EMPTY;

        // Casos especiales
        $result = "";

        // Peón: avance doble → habilitar captura al paso
        if (abs($piece) === self::PAWN && abs($toRow - $fromRow) === 2) {
            $this->enPassantTarget = [($fromRow + $toRow) / 2, $fromCol];
        }

        // Captura al paso real
        if (abs($piece) === self::PAWN && $fromCol !== $toCol && $this->board[$toRow][$toCol] === 0) {
            $this->board[$fromRow][$toCol] = self::EMPTY; // Eliminar peón capturado
        }

        // Promoción de peón
        if (abs($piece) === self::PAWN && ($toRow === 0 || $toRow === 7)) {
            $this->board[$toRow][$toCol] = $color * self::QUEEN; // Auto-promover a reina
            $result = "promotion";
        }

        // Enroque: mover la torre también
        if (abs($piece) === self::KING) {
            $backRow = $color === self::WHITE ? 7 : 0;
            if ($fromCol === 4 && $toCol === 6) { // Rey lado
                $this->board[$backRow][5] = $this->board[$backRow][7];
                $this->board[$backRow][7] = self::EMPTY;
            } elseif ($fromCol === 4 && $toCol === 2) { // Reina lado
                $this->board[$backRow][3] = $this->board[$backRow][0];
                $this->board[$backRow][0] = self::EMPTY;
            }
            // Revocar derechos de enroque del rey
            $idx = $color === self::WHITE ? 0 : 2;
            $this->castlingRights[$idx] = false;
            $this->castlingRights[$idx + 1] = false;
        }

        // Revocar derechos de enroque de torres
        if (abs($piece) === self::ROOK) {
            if ($fromRow === 7 && $fromCol === 7) $this->castlingRights[0] = false;
            if ($fromRow === 7 && $fromCol === 0) $this->castlingRights[1] = false;
            if ($fromRow === 0 && $fromCol === 7) $this->castlingRights[2] = false;
            if ($fromRow === 0 && $fromCol === 0) $this->castlingRights[3] = false;
        }

        // Verificar jaque, jaque mate y ahogado para el oponente
        $opponent = -$color;
        if ($this->isInCheck($opponent)) {
            if ($this->hasNoMoves($opponent)) {
                $result = "checkmate";
            } else {
                $result = "check";
            }
        } elseif ($this->hasNoMoves($opponent)) {
            $result = "stalemate";
        }

        return $result;
    }

    public function isInCheck(int $color): bool {
        // Encontrar rey
        foreach ($this->board as $row => $cols) {
            foreach ($cols as $col => $piece) {
                if ($piece === $color * self::KING) {
                    return $this->isSquareAttacked($row, $col, -$color);
                }
            }
        }
        return false;
    }

    private function isSquareAttacked(int $row, int $col, int $attackerColor): bool {
        // Verificar si alguna pieza del color atacante puede llegar a esa casilla
        foreach ($this->board as $r => $cols) {
            foreach ($cols as $c => $piece) {
                if ($this->getColor($r, $c) !== $attackerColor) continue;
                $moves = $this->getRawMoves($r, $c, abs($piece), $attackerColor);
                foreach ($moves as $move) {
                    if ($move[0] === $row && $move[1] === $col) return true;
                }
            }
        }
        return false;
    }

    private function wouldLeaveKingInCheck(int $fromRow, int $fromCol, int $toRow, int $toCol, int $color): bool {
        // Simular el movimiento
        $savedBoard = $this->board;
        $savedEnPassant = $this->enPassantTarget;

        $this->board[$toRow][$toCol] = $this->board[$fromRow][$fromCol];
        $this->board[$fromRow][$fromCol] = self::EMPTY;

        $inCheck = $this->isInCheck($color);

        // Restaurar tablero
        $this->board = $savedBoard;
        $this->enPassantTarget = $savedEnPassant;

        return $inCheck;
    }

    private function hasNoMoves(int $color): bool {
        foreach ($this->board as $row => $cols) {
            foreach ($cols as $col => $piece) {
                if ($this->getColor($row, $col) !== $color) continue;
                if (count($this->getValidMoves($row, $col)) > 0) return false;
            }
        }
        return true;
    }

    private function isInBounds(int $row, int $col): bool {
        return $row >= 0 && $row < 8 && $col >= 0 && $col < 8;
    }

    public function getBoard(): array {
        return $this->board;
    }

    public function toArray(): array {
        return [
            'board' => $this->board,
            'enPassant' => $this->enPassantTarget,
            'castling' => $this->castlingRights,
        ];
    }

    public function fromArray(array $data): void {
        $this->board = $data['board'];
        $this->enPassantTarget = $data['enPassant'];
        $this->castlingRights = $data['castling'];
    }
}
